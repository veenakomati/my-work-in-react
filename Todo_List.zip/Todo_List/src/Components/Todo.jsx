import React, { useRef, useState } from 'react'

import './Assets/Css/Todo.css'
import { useEffect } from 'react';
import Todoitem from './Todoitem';


let count = 0;
const Todo = () => {

    const[Todos,setTodos] = useState([]);
    const inputRef = useRef(null);

    const add = () =>{
        setTodos([...Todos,{no:count++,text:inputRef.current.value,display:""}]);
        inputRef.current.value = "";
        localStorage.setItem("Todos_count",count);
    }
    
    useEffect(()=>{
        setTodos(JSON.parse(localStorage.getItem("Todos")));
        count = localStorage.getItem("Todos_count");
    },[])

    useEffect(()=>{
       setTimeout(() =>{
         console.log(Todos);
        localStorage.setItem("Todos",JSON.stringify(Todos));
       },100);

    },[Todos])


  return (
    <div className='todo'>
        <div className="todo-header">To-Do List</div>
        <div className="todo-add">
            <input ref={inputRef} type="text" placeholder='Add Your Task' className='todo-input'/>
            <div onClick={()=>{add()}} className="todo-add-btn">Add</div>
        </div>
        <div className="todo-list">
            {Todos.map((item,index)=>{
                return <Todoitem key={index} setTodos={setTodos} no={item.no} display={item.display} text={item.text}/>
            })}

        </div>
      
    </div>
  )
}

export default Todo
