import React from 'react'
import Todo from './Components/Todo'

const App = () => {
  return (
    <div>
      <Todo/>
    </div>
  )
}

export default App
